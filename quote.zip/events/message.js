import pkg from "discord.js";
const { WebhookClient } = pkg;

import dotenv from "dotenv";
dotenv.config();

const webhook = new WebhookClient({
	id: process.env.WEBHOOK_ID,
	token: process.env.WEBHOOK_TOKEN
});

export default async (client, message) => {
	if (message.id.remote == "120363073213956365@g.us") {
		const sender = await message.getContact();
		const media = await message.downloadMedia();		

		webhook.send({
			content: message.body,
			username: `${sender.pushname}`,
			avatarURL: (await sender.getProfilePicUrl()) || "https://cdn.imaperson.dev/whatsapp-default.png",
			files: media ? [ new Buffer.from(media.data, "base64") ] : []
		});
	}
}