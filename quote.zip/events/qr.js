import qrcode from "qrcode-terminal";

export default async (client, qr) => {
	qrcode.generate(qr, { small: true });
}