export default async client => {
	console.log("WhatsApp Bot is ready!");
}